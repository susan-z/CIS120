=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=
CIS 120 Game Project README
PennKey: _______
=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=

===================
=: Core Concepts :=
===================

- List the four core concepts, the features they implement, and why each feature
  is an approprate use of the concept. Incorporate the feedback you got after
  submitting your proposal.

  1. 2-D Arrays: Creates the floorplan for each level 
  Pre-made 2-D array floorplans allow the creator to control the level of difficulty and
  ensure that completion of the level is possible. I will be able to create a grid-like
  structure and map out walls, enemies, and other features (possibly coins), then repaint 
  as the user moves and changes location using the keyboard arrows.

  2. I/O: Maintaining high score logs
  A user will implement a username prior to gameplay. A format of "Name, score" will be 
  written into a file, and sorted in decreasing order. Only the top three scores will 
  be displayed after the game.

  3. Inheritance/Subtyping for Dynamic Dispatch: Creating multiple enemies
  Each enemy will inherit an interface with several commands such as .move or .attack, but 
  will implement these methods differently. Some enemies would attack with fireballs while
  another would stun the user, making them lose time. I plan on changing the frequency with 
  which the enemies attack, and the direction and speed of their movement on the floor.

  4. Testable: Ability to test certain qualities and actionListener events in the game
  Some tests will include: moving in the correct direction after button-presses, being in 
  the expected location either after key-press or after a duration of time (not in a wall
  or beyond the map), ending the game when the user runs out of time or gets hit by an enemy, 
  time after a stun attack, and several more to ensure functionality of the game. 


=========================
=: Your Implementation :=
=========================

- Provide an overview of each of the classes in your code, and what their
  function is in the overall game.
  
Game -contains the main methods and structures the frame and widgets of the GUI
  
Enemies = dragons

Floorplan -2D arrays for each of the three levels
includes timer
Action listener

DragonInterface -all methods of enemies 
Dragon1 -doesn't move, shoots stunning fireballs
Dragon2 -moves, dosen't attack
Dragon3 -moves and attacks by shooting fireballs
Knight

import images
collisions by comparing .getX or pos.X something like that


- Were there any significant stumbling blocks while you were implementing your
  game (related to your design, or otherwise)?


- Evaluate your design. Is there a good separation of functionality? How well is
  private state encapsulated? What would you refactor, if given the chance?



========================
=: External Resources :=
========================

- Cite any external resources (libraries, images, tutorials, etc.) that you may
  have used while implementing your game.


